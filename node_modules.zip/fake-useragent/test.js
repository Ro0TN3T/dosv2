var fakeUa = require('./index');
for (var i = 0; i < 10; i++) {
  console.log(fakeUa());
}
